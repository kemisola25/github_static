function reverseString(str) {
    var newString = "";
    for (var i = str.length - 1; i >= 0; i--) {
        newString += str[i];
    }
    return newString;
}

/** Answer Starts from here */
//Question 3
let numberArray = [1, 2, 3, 4, 5, 6];
function sum (a, b, c, d, e, f){
  let n = a + b + c + d + e + f;
  return n;
}console.log(sum(1,2,3,4,5,6));

function average(n){
   for(let n = 0; n < numberArray.length; n++){
       numberArray[n] = numberArray[n] / 6;
   }return console.log(numberArray);
}average([1,2,3,4,5,6])

 
   
    


//Question 2

let Cars = {wheel: 'four wheeled', capacity: 'small number of people' , Property: '2 doors, 4 tyre, 2 rearSeat, 1 windsheild, 2 sideMirrors'};
console.log(Cars);
function carSideMirrorChecker(){
   if(aCar.Property === '2 doors, 4 tyre, 2 rearSeat, 1 windsheild, 2 sideMirrors' ){
        console.log("The car has the following properties "+ aCar.Property);}
       else{ 
            console.log("say nothing");
       }
   }

